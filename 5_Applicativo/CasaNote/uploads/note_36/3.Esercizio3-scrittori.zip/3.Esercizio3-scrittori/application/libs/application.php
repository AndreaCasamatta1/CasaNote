<?php

class Application
{
    private $url_controller = null;
    private $url_action = null;
    private $url_parameter_1 = null;
    private $url_parameter_2 = null;
    private $url_parameter_3 = null;

    public function __construct()
    {

        $this->splitUrl(); //funzione da creare per dividere l'URL

        if ($this->url_controller) {
            $controller_file = './application/controller/' . $this->url_controller . '.php';
            if (file_exists($controller_file)) {
                require $controller_file;
                $this->url_controller = new $this->url_controller();
                if (method_exists($this->url_controller, $this->url_action)) {
                    if (isset($this->url_parameter_3)) {
                        $this->url_controller->{$this->url_action}($this->url_parameter_1, $this->url_parameter_2,
                            $this->url_parameter_3);
                    } elseif (isset($this->url_parameter_2)) {
                        $this->url_controller->{$this->url_action}($this->url_parameter_1, $this->url_parameter_2);
                    } elseif (isset($this->url_parameter_1)) {
                        $this->url_controller->{$this->url_action}($this->url_parameter_1);
                    } else {
                        $this->url_controller->{$this->url_action}();
                    }
                } else {
                    $this->url_controller->index();
                }
            } else {
                require './application/controller/login.php';
                $home = new Login();
                $home->index();
            }
        } else {
            require './application/controller/login.php';
            $home = new Login();
            $home->index();
        }
    }

    /**
     * Splitto l'url URL
     */
    private function splitUrl()
    {
        if (isset($_GET['url'])) {
            $url = rtrim($_GET['url'], '/');
            $url = filter_var($url, FILTER_SANITIZE_URL);
            $url = explode('/', $url);

            // Validazione del controller
            $this->url_controller = (isset($url[0]) ? $url[0] : null);
            if ($this->url_controller && !preg_match('/^[a-zA-Z0-9_]+$/', $this->url_controller)) {
                $this->url_controller = null;
            }

            // Validazione dell'azione
            $this->url_action = (isset($url[1]) ? $url[1] : '');
            if ($this->url_action && !preg_match('/^[a-zA-Z0-9_]+$/', $this->url_action)) {
                $this->url_action = '';
            }

            $this->url_parameter_1 = (isset($url[2]) ? $url[2] : null);
            $this->url_parameter_2 = (isset($url[3]) ? $url[3] : null);
            $this->url_parameter_3 = (isset($url[4]) ? $url[4] : null);


        }
    }
}
