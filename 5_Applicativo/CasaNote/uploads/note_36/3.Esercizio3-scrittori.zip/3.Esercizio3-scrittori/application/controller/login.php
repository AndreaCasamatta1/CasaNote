<?php
class Login
{
    public function __construct()
    {
    }

    public function index()
    {
        require_once 'application/models/Scrittore.php';
        require_once 'application/views/_templates/header.php';
        require_once 'application/views/login/index.php';
        require_once 'application/views/_templates/footer.php';
        
    }

    public function logIn()
    {
        if (isset($_POST['login'])) {
            if (!isset($_POST['csrf_token']) || !CsrfTokenManager::validateToken($_POST['csrf_token'])) {
                die("CSRF token non valido!");
            }
            else {
                require_once 'application/controller/check.php';
                require_once 'application/models/Accesso.php';
                $login = new Accesso();
                $username = Check::filterField($_POST['username']);
                $pass = Check::filterField($_POST['pass']);
                $user = Accesso::where('username', $username)->first();
                if ($user && password_verify($pass, $user->password)) {


                    $_SESSION["tipo"] = $user['tipo'];
                    $_SESSION["nome"] = $user['nome'];
                    $_SESSION["cognome"] = $user['cognome'];

                    header("Location:" . URL . "home");
                } else {
                    $this->index();
                }
            }

        }

    }


}
