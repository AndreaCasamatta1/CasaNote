<?php


class Home
{
    private $scrittori;


    public function index()
    {

        $scrittori = Scrittore::all();
        $_SESSION['scrittori'] = $scrittori;
        header("location: " . URL . "home/showWriters");
    }


    public function showWriters()
    {

        if (isset($_SESSION["tipo"])) {
            require_once 'application/views/_templates/header.php';

            if (!isset($_SESSION['benvenuto'])) {
                $_SESSION['benvenuto'] = $benvenuto = "Benvenuto " . $_SESSION['cognome'];
            }
            if ($_SESSION["tipo"] == "admin") {
                require 'application/views/home/search.php';

            }

            require 'application/views/home/index.php';
            require_once 'application/views/_templates/footer.php';
        } else {
            header("location: " . URL . "login/");
        }

    }


    public function filter()
    {

        if (isset($_SESSION["tipo"])) {
            if (!isset($_POST['csrf_token']) || !CsrfTokenManager::validateToken($_POST['csrf_token'])) {
                die("CSRF token non valido!");
            }
            else{
                $scrittori = "";

                if (isset($_POST['field'])) {
                    require_once 'application/controller/check.php';
                    $field = Check::filterFIeld($_POST['field']);

                    $scrittori = Scrittore::where('nome', 'LIKE', '%' . $field . '%')
                        ->orWhere('cognome', 'LIKE', '%' . $field . '%')
                        ->orWhere('nazione', 'LIKE', '%' . $field . '%')
                        ->orWhere('nascita', 'LIKE', '%' . $field . '%')
                        ->get();
                }
                unset($_SESSION['scrittori']);
                $_SESSION['scrittori'] = $scrittori;
                header("location: " . URL . "home/showWriters");
            }

        } else {
            header("location: " . URL . "login/");
        }
    }


    public function order($field)
    {
        if (isset($_SESSION["tipo"]) && $_SESSION['tipo'] == 'admin') {
            require_once 'application/controller/check.php';
            $field = Check::filterFIeld($field);
            $orderType = "DESC";

            //nel caso di desc
            if (isset($_SESSION['currentOrderField'])) {
                if ($field == $_SESSION['currentOrderField']) {
                    if (isset($_SESSION['orderType'])) {
                        if ($_SESSION['orderType'] == "DESC") {
                            $orderType = "ASC";
                        }
                    }
                }
            }

            $_SESSION['currentOrderField'] = $field;
            $_SESSION['orderType'] = $orderType;
            $scrittori = Scrittore::orderBy($field, $orderType)->get();


            $_SESSION['scrittori'] = $scrittori;


            header("location: " . URL . "home/showWriters");
        }
        else{
            header("location: " . URL . "home/showWriters");
        }
    }
    public function showTour($id)
    {
        require_once 'application/models/Evento.php';

        if (isset($_SESSION["tipo"])) {

            $scrittore = Scrittore::find($id);


            $eventi = Evento::where('scrittore_id', $id)->get();

            require_once 'application/views/_templates/header.php';
            require 'application/views/home/tour.php';
            require_once 'application/views/_templates/footer.php';
        } else {
            header("location: " . URL . "login/");
        }
    }

    public function create()
    {
        if (isset($_SESSION["tipo"]) && $_SESSION["tipo"] == "admin") {
            require_once 'application/models/Genere.php';
            $generi = Genere::all();

            require_once 'application/views/_templates/header.php';
            require 'application/views/home/create.php';
            require_once 'application/views/_templates/footer.php';
        } else {
            header("location: " . URL . "login/");
        }
    }
    public function add()
    {
        if (isset($_SESSION["tipo"]) && $_SESSION["tipo"] == "admin") {
            require_once 'application/models/Scrittore.php';

            $scrittore = new Scrittore();
            $scrittore->nome = $_POST['nome'];
            $scrittore->cognome = $_POST['cognome'];
            $scrittore->nascita = $_POST['nascita'];
            $scrittore->nazione = $_POST['nazione'];
            $scrittore->genere_nome = $_POST['genere_nome'];
            $scrittore->save();

            header("location: " . URL . "home/showWriters");
        } else {
            header("location: " . URL . "login/");
        }
    }

    public function logout()
    {
        session_destroy();
        header("location: " . URL);
    }


}
