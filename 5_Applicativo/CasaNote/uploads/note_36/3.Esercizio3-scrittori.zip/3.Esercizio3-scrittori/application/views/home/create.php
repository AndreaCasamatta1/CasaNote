<h2>Inserisci un nuovo scrittore</h2>
<form action="<?php echo URL; ?>home/add" method="POST">
    <label>Nome:</label><br>
    <input type="text" name="nome" required><br><br>

    <label>Cognome:</label><br>
    <input type="text" name="cognome" required><br><br>

    <label>Data di nascita:</label><br>
    <input type="date" name="nascita" required><br><br>

    <label>Nazione:</label><br>
    <input type="text" name="nazione" required><br><br>

    <label>Genere:</label><br>
    <select name="genere_nome" required>
        <option value="">Scegli</option>
        <?php foreach ($generi as $genere): ?>
            <option value="<?php echo $genere->nome; ?>"><?php echo $genere->nome; ?></option>
        <?php endforeach; ?>
    </select><br><br>

    <button type="submit">Aggiungi</button>
</form>


