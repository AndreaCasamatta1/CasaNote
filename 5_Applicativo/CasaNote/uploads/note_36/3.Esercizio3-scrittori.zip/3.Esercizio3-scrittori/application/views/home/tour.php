
<h2>Tour promozionali di <?php echo $scrittore->nome . ' ' . $scrittore->cognome; ?></h2>
<br>
<table style="border: 1px solid black; border-collapse: collapse;">
    <thead>
    <tr>
        <th style="border: 1px solid black; padding: 10px;">Luogo</th>
        <th style="border: 1px solid black; padding: 10px;">Data</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($eventi as $evento): ?>
        <tr>
            <td style="border: 1px solid black; padding: 10px;"><?php echo $evento->luogo; ?></td>
            <td style="border: 1px solid black; padding: 10px;"><?php echo $evento->data; ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>


