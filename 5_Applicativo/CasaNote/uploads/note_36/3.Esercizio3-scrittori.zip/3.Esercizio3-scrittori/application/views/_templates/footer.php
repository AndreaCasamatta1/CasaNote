<p></p>
</div>
<div class="m-1 p-1 bg-dark text-white">@Copyright MS <?php echo date('Y'); ?></div>
</body>
</html>