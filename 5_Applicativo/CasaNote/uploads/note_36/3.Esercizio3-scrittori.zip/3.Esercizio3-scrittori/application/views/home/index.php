<br>



<h2><?php echo $_SESSION['benvenuto']; ?></h2>
<br>
<h1>Lista degli scrittori</h1>


<?php
?>
<p>
<table style="border: 1px solid black; border-collapse: collapse;">
    <thead>
    <tr>
        <th style="border: 1px solid black; padding: 10px;"><a href="<?php echo URL ?>home/order/nome">Nome</a></th>
        <th style="border: 1px solid black; padding: 10px;"><a href="<?php echo URL ?>home/order/cognome">Cognome</a></th>
        <th style="border: 1px solid black; padding: 10px;"><a href="<?php echo URL ?>home/order/nascita">Anni</a></th>
        <th style="border: 1px solid black; padding: 10px;"><a href="<?php echo URL ?>home/order/nazione">Nazione</a></th>
        <th style="border: 1px solid black; padding: 10px;"><a href="<?php echo URL ?>home/order/nazione">Genere</a></th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($_SESSION['scrittori'] as $scrittore): ?>
        <tr>
            <td style="border: 1px solid black; padding: 10px;">
                <a href="<?php echo URL . 'home/showTour/' . $scrittore->id; ?>">
                    <?php echo $scrittore->nome; ?>
                </a>
            </td>
            <td style="border: 1px solid black; padding: 10px;"><?php echo $scrittore->cognome; ?></td>
            <td style="border: 1px solid black; padding: 10px;"><?php echo $scrittore->nascita; ?></td>
            <td style="border: 1px solid black; padding: 10px;"><?php echo $scrittore->nazione; ?></td>
            <td style="border: 1px solid black; padding: 10px;"><?php echo $scrittore->genere->nome; ?></td>
        </tr>

    <?php endforeach; ?>



    </tbody>
</table>
<br>
<?php if ($_SESSION["tipo"] == "admin"): ?>
    <p><a href="<?php echo URL; ?>home/create"> Inserisci nuovo scrittore</a></p>
<?php endif; ?>

<p><br>
    <a href="<?php echo URL; ?>home/logout">Logout</a>

