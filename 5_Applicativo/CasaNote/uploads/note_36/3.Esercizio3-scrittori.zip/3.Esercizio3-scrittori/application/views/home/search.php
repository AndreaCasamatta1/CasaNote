<h2>Ricerca</h2>
<form action="<?php echo URL; ?>home/filter" method="POST">
    <input type='text' name='field'>
    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
    <input type="submit">
</form>