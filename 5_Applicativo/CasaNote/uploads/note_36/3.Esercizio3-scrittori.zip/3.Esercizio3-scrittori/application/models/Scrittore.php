<?php

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Scrittore extends Model
{
    protected $table = 'scrittore';
    public $timestamps = false; //   riga è necessaria per evitare errore su created_at/updated_at https://stackoverflow.com/questions/28277955/laravel-unknown-column-updated-at
    public function genere()
    {
        return $this->belongsTo(Genere::class, 'genere_nome', 'nome');
    }

}

?>

