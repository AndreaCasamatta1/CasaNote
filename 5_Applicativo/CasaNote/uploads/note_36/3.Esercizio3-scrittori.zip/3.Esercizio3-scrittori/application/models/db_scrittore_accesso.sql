CREATE DATABASE IF NOT EXISTS eloquent;
USE eloquent;

DROP TABLE IF EXISTS evento;
DROP TABLE IF EXISTS scrittore;
DROP TABLE IF EXISTS genere;
DROP TABLE IF EXISTS accesso;

CREATE TABLE accesso
(
    id       INT          NOT NULL AUTO_INCREMENT,
    username VARCHAR(50)  NOT NULL,
    password VARCHAR(255) NOT NULL,
    nome     VARCHAR(50),
    cognome  VARCHAR(50),
    citta    VARCHAR(50),
    tipo     VARCHAR(10)  NOT NULL,
    PRIMARY KEY (id)
);


CREATE TABLE genere
(
    nome        VARCHAR(50) NOT NULL,
    descrizione TEXT DEFAULT NULL,
    PRIMARY KEY (nome)
);


CREATE TABLE scrittore
(
    id          INT NOT NULL AUTO_INCREMENT,
    nome        VARCHAR(100),
    cognome     VARCHAR(100),
    nascita     DATE,
    nazione     VARCHAR(50),
    genere_nome VARCHAR(50),
    PRIMARY KEY (id),
    FOREIGN KEY (genere_nome) REFERENCES genere (nome)
        ON DELETE SET NULL
        ON UPDATE CASCADE
);

CREATE TABLE evento
(
    id           INT NOT NULL,
    luogo        VARCHAR(100) DEFAULT NULL,
    data         DATE         DEFAULT NULL,
    scrittore_id INT          DEFAULT NULL,
    PRIMARY KEY (id),
    KEY          scrittore_id (scrittore_id),
    CONSTRAINT evento_ibfk_1 FOREIGN KEY (scrittore_id)
        REFERENCES scrittore (id)
        ON DELETE CASCADE
);


INSERT INTO genere (nome, descrizione)
VALUES ('romanzo', 'Narrazione lunga e fittizia con personaggi e trama'),
       ('saggio', 'Testo analitico o argomentativo su un tema specifico'),
       ('poesia', 'Composizione in versi con valore estetico ed emotivo'),
       ('biografico', 'Racconto della vita di una persona reale'),
       ('fantasy', 'Genere narrativo con elementi magici o sovrannaturali');

INSERT INTO scrittore (nome, cognome, nascita, nazione, genere_nome)
VALUES ( 'Italo', 'Calvino', '2000-02-23', 'Italia', 'romanzo'),
       ( 'Margaret', 'Atwood', '2009-01-22', 'Canada', 'saggio'),
       ('Gabriel', 'García Márquez', '2001-01-21', 'Colombia', 'romanzo'),
       ( 'Wislawa', 'Szymborska', '2002-02-22', 'Polonia', 'poesia'),
       ('Stephen', 'King', '2003-02-23', 'USA', 'romanzo'),
       ( 'Haruki', 'Murakami', '2004-12-29', 'Giappone', 'poesia'),
       ( 'J.K.', 'Rowling', '2005-09-23', 'Inghilterra', 'fantasy'),
       ('Isabel', 'Allende', '2006-08-20', 'Cile', 'biografico');


INSERT INTO evento (id, luogo, data, scrittore_id)
VALUES (1, 'Milano', '2029-01-22', 1),
       (2, 'Toronto', '2027-02-23', 2),
       (3, 'Bogotà', '2026-03-24', 3),
       (4, 'Varsavia', '2025-09-25', 4);


INSERT INTO accesso (username, password, nome, cognome, citta, tipo)
VALUES ('admin', '$2y$10$pqVoNg.c33RPAEO6mL9.0.8BH4686GPMOyJhEanQfvbdvpEdboBce', 'Gino', 'Perollo', 'Locarno', 'admin'),
       ('user', '$2y$10$3jzzamiMbxQvFoWGYhcVtOwf3HZ8W40tA/Yeel4ZuUL6NFZXP7DSK', 'Massimo', 'Meridio', 'Roma', 'user');
