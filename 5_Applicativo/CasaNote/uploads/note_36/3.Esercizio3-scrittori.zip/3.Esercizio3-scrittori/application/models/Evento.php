<?php

use Illuminate\Database\Eloquent\Model;

class Evento extends Model
{
    protected $table = 'evento';

    public function scrittore()
    {
        return $this->belongsTo(Scrittore::class, 'scrittore_id');
    }
}
