<?php
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Genere extends Model
{
    protected $table = 'genere';
    public function scrittori()
    {
        return $this->hasMany(Scrittore::class);
    }
}