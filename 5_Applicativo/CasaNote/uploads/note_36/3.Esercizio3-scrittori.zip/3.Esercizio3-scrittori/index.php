<?php


require 'application/config/config.php';

require_once "vendor/autoload.php";
require_once "application/libs/CsrfTokenManager.php";
require_once "application/libs/database.php";

$csrf = new CsrfTokenManager();
//$GLOBALS['csrf_token'] = $csrf->getToken();

$db = new Database();

// faccio partire l'applicazione
$app = new Application();
